# Tadabbur Quran — تێڕامان لە قورئان

Farahi School app matching the **tadabbur-v6 web app** design system:
cream parchment (`#F5F0E6`) + deep emerald (`#0A3E35`) + royal gold (`#B38222`),
Amiri Quran (Mushaf) + Vazirmatn (Kurdish UI) typefaces.

## Structure (mirrors the v6 web app)

- **Home**: Gateway Card (ناساندنی قوتابخانەی فەراهی · ئەندازیاریی نەزم · پێوەر ١:١١)
  + Stats Row (١١٤ · ٧ · ٥٧ · ٣٠) + search + مەککی/مەدەنی pills + surah list
- **Farahi Portal** (`/hub`): شۆڕشی ڕەوانبێژی header + «كِتَابٌ أُحْكِمَتْ آيَاتُهُ»
  with 5 tabs: زانایان · کەوانە و عەموود · حەوت کۆمەڵە · ٥٧ جووتەکە · زمانی کۆن
- **Surah details**: 30% Bunny video, هاوتای سوورەتەکە twin banner, ayah +
  Kurdish translation + animated نەزم/ستوون/تێڕامان/زمانەوانی pillar tabs
- **Supabase**: 6 Farahi pillar columns/ayah + Seven Groups + twinning + FTS
- **Smart regex parser** (master text block → typed columns), `test/` covered
- **CI**: GitHub Actions builds a release APK on every push

## Roadmap

- [x] Day 1–5 — foundation, adaptive UI, parser, Seven Groups, Knowledge Hub
- [x] v6 port — cream/emerald/gold theme + home + Farahi Portal tabs
- [ ] Day 6 — Bunny video player (episodes carousel like v6 video sheet), repository layer
