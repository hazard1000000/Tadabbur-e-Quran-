# Fonts

This directory must contain the following font files (referenced in `pubspec.yaml`).
Font binaries are NOT committed to this repo due to licensing — download them and place them here:

| File                              | Purpose                              | Source |
|-----------------------------------|--------------------------------------|--------|
| `UthmanicScriptKFGQPC-Regular.otf` | Quranic text (Uthmani script)        | KFGQPC — free, redistributable: https://fonts.qurancomplex.gov.sa/ |
| `UthmanicScriptKFGQPC-Bold.otf`    | Quranic text bold                    | same as above |
| `Kurdish-Regular.ttf`              | Kurdish UI text                      | NRT / Rabar (license permitting) or **Vazirmatn** (OFL): https://github.com/rastikerdar/vazirmatn |
| `Kurdish-Bold.ttf`                 | Kurdish UI text bold                 | same as above |
| `NotoSans-Regular.ttf`             | Latin fallback                       | https://fonts.google.com/noto (OFL) |
| `NotoSans-Bold.ttf`                | Latin fallback bold                  | same as above |

> Tip: If your chosen Kurdish font ships under a different filename (e.g.
> `Vazirmatn-Regular.ttf`), either rename the file or update `pubspec.yaml`.
