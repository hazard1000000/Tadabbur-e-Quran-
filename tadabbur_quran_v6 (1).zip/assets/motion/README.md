# Motion assets (Lottie)

The Knowledge Hub loads `pillar_<0..4>.json` from this directory
(0 = groups, 1 = pairs, 2 = axis, 3 = nazm, 4 = mufradat).

- Export from After Effects / Rive as Lottie JSON, ~20–40 KB each.
- Until a file is present, `PillarMotionAsset` automatically renders an
  animated fallback icon, so missing assets never break the UI.
