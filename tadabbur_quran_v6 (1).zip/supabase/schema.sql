-- ============================================================
-- Tadabbur Quran — Supabase schema (Day 4: Farahi macro-structure)
-- Seven Groups (العمارة/المراحل السبع) + surah pairing (الزوج القرآني)
-- ============================================================

-- ---- The Seven Groups of the Quran (Islahi's grouping) ----
create table if not exists public.quran_groups (
  group_number  smallint primary key check (group_number between 1 and 7),
  name_ar       text not null,
  name_ku       text not null,
  theme_ku      text not null,        -- localized academic theme of the group
  first_surah   smallint not null,    -- e.g. 1
  last_surah    smallint not null,    -- e.g. 5
  created_at    timestamptz not null default now()
);

create table if not exists public.surahs (
  id                 smallint primary key check (id between 1 and 114),
  arabic_name        text not null,
  kurdish_name       text not null,
  revelation_type    text not null check (revelation_type in ('meccan', 'medinan')),
  total_ayahs        smallint not null,
  -- ---- Farahi macro-structure ----
  group_number       smallint not null references public.quran_groups(group_number),
  paired_surah_id    smallint references public.surahs(id),   -- structural twin (الزوج القرآني)
  pairing_context_ku text,          -- Kurdish academic summary of the pair's link
  created_at         timestamptz not null default now()
);

-- One row per ayah, holding ALL Farahi pillars as first-class columns.
create table if not exists public.ayahs (
  id                   bigint generated always as identity primary key,
  surah_id             smallint not null references public.surahs(id) on delete cascade,
  ayah_number          smallint not null,
  arabic_text          text not null,
  kurdish_translation  text,               -- [وەرگێڕان]
  nazm                 text,               -- [نەزم]  structural coherence
  amud                 text,               -- [عەموود] central theme / axis
  tadabbur             text,               -- [تەدبّور] reflections + historical context
  language_analysis    text,               -- [زمان] linguistic / balagha
  source_block_hash    text,
  updated_at           timestamptz not null default now(),
  created_at           timestamptz not null default now(),
  unique (surah_id, ayah_number)
);

-- Bunny-hosted lectures. Supabase keeps only metadata + stream URLs.
create table if not exists public.lectures (
  id                bigint generated always as identity primary key,
  surah_id          smallint not null references public.surahs(id) on delete cascade,
  title             text not null,
  title_ku          text,
  bunny_video_id    text,
  video_url         text not null,
  subtitle_url_ku   text,
  duration_seconds  integer,
  sort_order        smallint default 0,
  created_at        timestamptz not null default now()
);

-- Twin traversal index: "which surah am I the twin of?" (self-join fast path).
create index if not exists surahs_twin_idx    on public.surahs (paired_surah_id);
create index if not exists surahs_group_idx   on public.surahs (group_number, id);
create index if not exists ayahs_surah_idx    on public.ayahs (surah_id, ayah_number);
create index if not exists lectures_surah_idx on public.lectures (surah_id);

-- Full-text search across Arabic + Kurdish Tafsir.
alter table public.ayahs
  add column if not exists search_vector tsvector
  generated always as (
    setweight(to_tsvector('simple', coalesce(arabic_text, '')), 'A') ||
    setweight(to_tsvector('simple', coalesce(kurdish_translation, '')), 'B') ||
    setweight(to_tsvector('simple', coalesce(tadabbur, '')), 'C')
  ) stored;
create index if not exists ayahs_fts_idx on public.ayahs using gin (search_vector);

-- ------------------------------------------------------------
-- Seed: Islahi's Seven Groups (edit themes_ku freely via admin).
-- ------------------------------------------------------------
insert into public.quran_groups (group_number, name_ar, name_ku, theme_ku, first_surah, last_surah) values
  (1, 'المثاني', 'موسڵا/دووبارەکان', 'بنچینەکانی عەقیدە و جیاوازی ئوممەتەکان', 1, 5),
  (2, 'المجادل', 'گروپی دووەم', 'بەسڕاوەكردنەوەی عەقیدە و بەرەنگاریی دوژمنان', 6, 9),
  (3, '—', 'گروپی سێیەم', 'قورئان وەکو موعجیزە و داڕشتنەوەی سەردەمی داهاتوو', 10, 24),
  (4, '—', 'گروپی چوارەم', 'سەرکێشی عەقڵی و پەرەپێدانی باوەڕی تاکەکەسی', 25, 33),
  (5, '—', 'گروپی پێنجەم', 'موعجیزاتی زانستی و مەسەلەکانی ئاین', 34, 49),
  (6, '—', 'گروپی شەشەم', 'دیموکراسیای عەقڵی و ژیانی دوای مەرگ', 50, 66),
  (7, 'المفصل', 'موفەسسڵ/وردەکارەکان', 'کورتەسوورەتەکان — پەیامی کورت و کاریگەر', 67, 114)
on conflict (group_number) do nothing;

-- ------------------------------------------------------------
-- RLS: anon read-only; authenticated admin writes.
-- ------------------------------------------------------------
alter table public.quran_groups enable row level security;
alter table public.surahs      enable row level security;
alter table public.ayahs       enable row level security;
alter table public.lectures    enable row level security;

create policy "public read groups"  on public.quran_groups for select using (true);
create policy "public read surahs"  on public.surahs      for select using (true);
create policy "public read ayahs"   on public.ayahs       for select using (true);
create policy "public read lectures" on public.lectures   for select using (true);

create policy "admin write ayahs"   on public.ayahs
  for all to authenticated using (true) with check (true);
create policy "admin write surahs"  on public.surahs
  for all to authenticated using (true) with check (true);
