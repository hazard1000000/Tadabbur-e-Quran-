import 'package:flutter_test/flutter_test.dart';
import 'package:tadabbur_quran/core/utils/farahi_text_parser.dart';

void main() {
  const sample = '''
[سوورەت: 94] [ئایەت: 5]
[عەرەبی:] فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا
[وەرگێڕان:] بەڵکو لەگەڵ سەختییەکەدا ئاسانییەک هەیە.
[نەزم:] پەیوەندی ئەم ئایەتە بە ئایەتی پێشوو: پێش ئامانە، ئێستا بەڵێن.
[عەموود:] ناونوسی سوورەتەکە: فراوانی دڵ و شادوخۆشی دوای تەنگانە.
[تەدبّور:] بیرکردنەوە لە واقیعی مەککەی زمان و گەرما و دڵەڕاوکێی پێغەمبەر ﷺ.
[زمان:] (مَعَ) حرف جار، (ٱلْعُسْرِ) کەواتە هەرچەندە لە کێشەدای، ئاسانی لەگەڵدایە.
''';

  test('parses a well-formed master block into all six fields', () {
    final r = FarahiTextParser.parse(sample);
    expect(r.surahId, 94);
    expect(r.ayahNumber, 5);
    expect(r.arabicText, startsWith('فَإِنَّ'));
    expect(r.kurdishTranslation, contains('سەختییەکەدا'));
    expect(r.nazm, contains('پەیوەندی'));
    expect(r.amud, contains('فراوانی'));
    expect(r.tadabbur, contains('مەککە'));
    expect(r.languageAnalysis, contains('حرف جار'));
    expect(r.warnings, isEmpty);
  });

  test('accepts Arabic-Indic digits and spelling variants', () {
    final r = FarahiTextParser.parse(
      '[سوورەت: ٩٤] [ئایەت: ٥]\n[عەرەبی:] نَصّ\n[تەدەبوور:] بیرکردنەوە',
    );
    expect(r.surahId, 94);
    expect(r.ayahNumber, 5);
    expect(r.tadabbur, 'بیرکردنەوە');
  });

  test('throws when the header is missing', () {
    expect(
      () => FarahiTextParser.parse('[عەرەبی:] نَصّ'),
      throwsFormatException,
    );
  });

  test('throws when [عەرەبی:] is missing', () {
    expect(
      () => FarahiTextParser.parse('[سوورەت: 2] [ئایەت: 1]\n[نەزم:] فقط'),
      throwsFormatException,
    );
  });

  test('reports out-of-range surah', () {
    expect(
      () => FarahiTextParser.parse('[سوورەت: 200] [ئایەت: 1]\n[عەرەبی:] x'),
      throwsFormatException,
    );
  });

  test('supabase row keys match the schema columns', () {
    final row = FarahiTextParser.parse(sample).toSupabaseRow();
    expect(row.keys, containsAll([
      'surah_id', 'ayah_number', 'arabic_text', 'kurdish_translation',
      'nazm', 'amud', 'tadabbur', 'language_analysis',
    ]));
  });
}
