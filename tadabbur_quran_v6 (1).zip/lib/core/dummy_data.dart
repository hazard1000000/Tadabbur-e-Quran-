import '../features/lectures/data/models/lecture_model.dart';
import '../features/quran/data/models/ayah_model.dart';
import '../features/quran/data/models/quran_group_model.dart';
import '../features/quran/data/models/surah_model.dart';
import 'constants/enums.dart';

/// Temporary dummy data mirroring the Day 4 Supabase schema.
/// DELETE after admin-panel import.
abstract final class DummyData {
  /// Islahi's Seven Groups — structurally correct naming.
  static const List<QuranGroupModel> groups = [
    QuranGroupModel(groupNumber: 1, nameAr: 'المثاني', nameKu: 'گروپی یەکەم', themeKu: 'بناغەی عەقیدە و جیاوازی ئوممەتەکان', firstSurah: 1, lastSurah: 5),
    QuranGroupModel(groupNumber: 2, nameAr: 'المجادل', nameKu: 'گروپی دووەم', themeKu: 'بەسڕاوەكردنەوەی عەقیدە و بەرەنگاریی دوژمنان', firstSurah: 6, lastSurah: 9),
    QuranGroupModel(groupNumber: 3, nameAr: '—', nameKu: 'گروپی سێیەم', themeKu: 'قورئان وەکو موعجیزە و داڕشتنەوەی سەردەمی داهاتوو', firstSurah: 10, lastSurah: 24),
    QuranGroupModel(groupNumber: 4, nameAr: '—', nameKu: 'گروپی چوارەم', themeKu: 'سەرکێشی عەقڵی و پەرەپێدانی باوەڕی تاکەکەسی', firstSurah: 25, lastSurah: 33),
    QuranGroupModel(groupNumber: 5, nameAr: '—', nameKu: 'گروپی پێنجەم', themeKu: 'موعجیزاتی زانستی و مەسەلەکانی ئاین', firstSurah: 34, lastSurah: 49),
    QuranGroupModel(groupNumber: 6, nameAr: '—', nameKu: 'گروپی شەشەم', themeKu: 'دیموکراسیای عەقڵی و ژیانی دوای مەرگ', firstSurah: 50, lastSurah: 66),
    QuranGroupModel(groupNumber: 7, nameAr: 'المفصل', nameKu: 'گروپی حەوتەم', themeKu: 'کورتەسوورەتەکان — پەیامی کورت و کاریگەر', firstSurah: 67, lastSurah: 114),
  ];

  /// 17 sample surahs with group + twin assignments (Farahi pairing).
  static final List<SurahModel> surahs = [
    const SurahModel(id: 1, arabicName: 'الفاتحة', kurdishName: 'الفاتحة', revelationType: RevelationType.meccan, totalAyahs: 7, groupNumber: 1),
    const SurahModel(id: 2, arabicName: 'البقرة', kurdishName: 'البقرة', revelationType: RevelationType.medinan, totalAyahs: 286, groupNumber: 1, pairedSurahId: 3,
      pairingContextKu: 'بەقەرە و ئال عومران هاوتایەکی تەواون: هەردووک لە مەدینە دابەزیون و بناغەی کۆمەڵگەی ئیسلامی دەگرنەبەر. بەقەرە یاسا و ڕێنمایی دەڕێژێت، ئال عومران بەرخۆردنی بەرامبەر هەڕەشە و تاقیکردنەوەکان دەخاتەڕوو.'),
    const SurahModel(id: 3, arabicName: 'آل عمران', kurdishName: 'آل عمران', revelationType: RevelationType.medinan, totalAyahs: 200, groupNumber: 1, pairedSurahId: 2,
      pairingContextKu: 'هاوتای بەقەرەیە: ئەگەر بەقەرە یاساکە بنیاد بنێت، ئال عومران لە پەنجەڕێی ئوحودەوە دەستپێدەکات — شەرع و ژیان بەپێکەوە.'),
    const SurahModel(id: 4, arabicName: 'النساء', kurdishName: 'النساء', revelationType: RevelationType.medinan, totalAyahs: 176, groupNumber: 1, pairedSurahId: 5),
    const SurahModel(id: 5, arabicName: 'المائدة', kurdishName: 'المائدة', revelationType: RevelationType.medinan, totalAyahs: 120, groupNumber: 1, pairedSurahId: 4),
    const SurahModel(id: 6, arabicName: 'الأنعام', kurdishName: 'الأنعام', revelationType: RevelationType.meccan, totalAyahs: 165, groupNumber: 2, pairedSurahId: 7),
    const SurahModel(id: 7, arabicName: 'الأعراف', kurdishName: 'الأعراف', revelationType: RevelationType.meccan, totalAyahs: 206, groupNumber: 2, pairedSurahId: 6),
    const SurahModel(id: 8, arabicName: 'الأنفال', kurdishName: 'الأنفال', revelationType: RevelationType.medinan, totalAyahs: 75, groupNumber: 2, pairedSurahId: 9),
    const SurahModel(id: 9, arabicName: 'التوبة', kurdishName: 'التوبة', revelationType: RevelationType.medinan, totalAyahs: 129, groupNumber: 2, pairedSurahId: 8),
    const SurahModel(id: 10, arabicName: 'يونس', kurdishName: 'يونس', revelationType: RevelationType.meccan, totalAyahs: 109, groupNumber: 3, pairedSurahId: 11),
    const SurahModel(id: 11, arabicName: 'هود', kurdishName: 'هود', revelationType: RevelationType.meccan, totalAyahs: 123, groupNumber: 3, pairedSurahId: 10),
    const SurahModel(id: 12, arabicName: 'يوسف', kurdishName: 'يوسف', revelationType: RevelationType.meccan, totalAyahs: 111, groupNumber: 3, pairedSurahId: 14),
    const SurahModel(id: 13, arabicName: 'الرعد', kurdishName: 'الرعد', revelationType: RevelationType.medinan, totalAyahs: 43, groupNumber: 3),
    const SurahModel(id: 14, arabicName: 'إبراهيم', kurdishName: 'إبراهيم', revelationType: RevelationType.meccan, totalAyahs: 52, groupNumber: 3, pairedSurahId: 12),
    const SurahModel(id: 15, arabicName: 'الحجر', kurdishName: 'الحجر', revelationType: RevelationType.meccan, totalAyahs: 99, groupNumber: 3),
    const SurahModel(id: 93, arabicName: 'الضحى', kurdishName: 'الضحى', revelationType: RevelationType.meccan, totalAyahs: 11, groupNumber: 7, pairedSurahId: 94,
      pairingContextKu: 'الضحى و الشرح هاوتایەکی دەگمەنن: هەردووک لە مەککە دابەزیون و بەدوای یەکدا دابەزیون. دۆحا بە سوێند دەست پێدەکات، الشرح بە پرسیار — هەمان بەڵێن، هەمان عەموود: تەسکینی پێغەمبەر ﷺ.'),
    const SurahModel(id: 94, arabicName: 'الشرح', kurdishName: 'الشرح', revelationType: RevelationType.meccan, totalAyahs: 8, groupNumber: 7, pairedSurahId: 93,
      pairingContextKu: 'الشرح هاوتای دۆحایە: دۆحا بە «وَٱلضُّحَىٰ» سوێند دەخوات، الشرح بە «أَلَمْ نَشْرَحْ» پرسیار — هەردووک دەگەیەنن: دڵفراوانی، لادانی بار، و هیوای هەمیشەیی.'),
  ];

  /// Structural pairs (الزوج القرآني) — deduped twin list for the Pairing view.
  /// The full 57 pairs are curated in Supabase; this is the dummy subset.
  static List<(SurahModel, SurahModel)> get pairs {
    final seen = <int>{};
    final result = <(SurahModel, SurahModel)>[];
    for (final s in surahs) {
      final t = s.pairedSurahId == null ? null : surahById(s.pairedSurahId!);
      if (t != null && !seen.contains(s.id) && !seen.contains(t.id)) {
        seen.addAll([s.id, t.id]);
        result.add((s, t));
      }
    }
    return result;
  }

  static List<SurahModel> surahsInGroup(int groupNumber) =>
      surahs.where((s) => s.groupNumber == groupNumber).toList();

  static SurahModel? surahById(int id) {
    for (final s in surahs) {
      if (s.id == id) return s;
    }
    return null;
  }

  static List<AyahModel> ayahsFor(int surahId) {
    if (surahId == 94) {
      return const [
        AyahModel(
          surahId: 94, ayahNumber: 1,
          arabicText: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ',
          kurdishTranslation: 'ئایا ئێمە دڵت نەفراوی نەکرد؟',
          nazm: 'دەستپێکی سوورەت بە پرسیارێکە — شێوازی بەرپرسانە کە خۆشەویستی و گرنگی بە قەڵاوی دەدات.',
          amud: 'فراوانی دڵ و شادوخۆشی دوای تەنگانە — ناونوسی سوورەتەکەیە (الشرح).',
          tadabbur: 'پێغەمبەر ﷺ لە مەککەدا لە گەورەترین فشاری کۆمەڵایەتی و کەسی دابوو؛ ئەم ئایەتە وەڵامی ئەو دۆخەیە.',
          languageAnalysis: 'أَلَمْ نَشْرَحْ: پرسیاری بەڵێن؛ صَدْرَكَ مفاعیل بە مانای «دڵ» هاتووە نەك «سنگ» تەنها.',
        ),
        AyahModel(
          surahId: 94, ayahNumber: 5,
          arabicText: 'فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا',
          kurdishTranslation: 'بەڵکو لەگەڵ سەختییەکەدا ئاسانییەک هەیە.',
          nazm: 'پەیوەندی بە ئایەتی پێشووەوە: پێش ئامانە، ئێستا بەڵێن. (فَإِنَّ) فەرامۆش ناکات.',
          amud: 'سەختی تەنیا نییە — ئاسانییەکەی لەگەڵ خۆیدا هەڵدەگرێت؛ ئەمە ستوونی سوورەتە.',
          tadabbur: 'بەپێی ئیسلاحی: سەختی دوو دەرگای هەیە و ئاسانییەکە دێتە ژوورەوە. بیرکردنەوە لە ژیانی ئەخلاقی و کۆمەڵایەتی.',
          languageAnalysis: '(مَعَ) حرف جار بمانای «لەگەڵ»؛ (ٱلْعُسْرِ) نکرانە، (يُسْرًا) مەفعول بە -ن تنوینی.',
        ),
        AyahModel(
          surahId: 94, ayahNumber: 6,
          arabicText: 'إِنَّ مَعَ ٱلْعُسْرِ يُسْرًا',
          kurdishTranslation: 'بەدڵنیاییەوە لەگەڵ سەختییەکەدا ئاسانییەک هەیە.',
          nazm: 'دووبارەکردنەوە بۆ دڵنیایی — ئەو بەڵێنە دوو جار دەهێنرێتەوە بۆ جددیەت.',
          amud: 'هێمایەکە بەهێزتر دەکاتەوە: سەختی دوو جار، ئاسانیش دوو جار.',
          tadabbur: 'تەدبوری ئیسلاحی: دووبارەکردنەوە مانای «هەمیشە» دەدات — هەر سەختێک دوو ئاسانی دەگرێتەوە.',
        ),
        AyahModel(
          surahId: 94, ayahNumber: 8,
          arabicText: 'وَإِلَىٰ رَبِّكَ فَٱرْغَب',
          kurdishTranslation: 'وە هیوات بۆ پەروەردگارت دابنێ.',
          nazm: 'کۆتایی سوورەت: لە شادوخۆیی دونیاییەوە بۆ مەبەستی هەمیشەیی دەڕوات.',
          amud: 'دڵنیایی لە سەختییەکان دەگەیەنێت بۆ تەفویزی هەموو کارەکان بۆ خوای گەورە.',
          tadabbur: 'فَٱرْغَب: ئارەزووکردن و دڵخۆشییەکی ڕەها — کۆتایی بەعەسرت بە هیوا بکە نەك بە دڵتەنگی.',
        ),
      ];
    }
    return const [
      AyahModel(
        surahId: 1, ayahNumber: 1,
        arabicText: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
        kurdishTranslation: 'بە ناوی خوای بەڕەحمە بەڕەحیمەوە.',
        nazm: 'سوورەت بە ناوپۆشانە دەست پێدەکات — هەموو کارێک بە ناوی خواوە.',
        amud: 'الرحمٰن الرحيم: ناونوسی سوورەت — رەحمی خوای گەورە.',
      ),
      AyahModel(
        surahId: 1, ayahNumber: 2,
        arabicText: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ',
        kurdishTranslation: 'هەموو سوپاس و ستایش بۆ خوای پەروەردگاری جیهانیانە.',
        amud: 'ستایشی خوای پەروەردگاری هەموو مرۆڤەکان — تەدبوری ئیسلاحی: هەموو سوپاس بۆ خوا.',
        tadabbur: 'رَّبِّ ٱلْعَٰلَمِينَ: پەروەردگاری هەموو جیهانەکان — بیرکردنەوە لە گەورەیی خوای گەورە.',
      ),
    ];
  }

  static final List<LectureModel> lectures = [
    const LectureModel(id: 1, surahId: 94, title: 'تدبر سورة الشرح — مع العسر يسر', videoUrl: 'https://vz-12345678.b-cdn.net/94-5/master.m3u8', subtitleUrl: 'https://cdn.tadabbur.app/subs/94.vtt', durationSeconds: 754),
    const LectureModel(id: 2, surahId: 1, title: 'فاتحة الكتاب — مقدمة التدبر', videoUrl: 'https://vz-12345678.b-cdn.net/1/master.m3u8', durationSeconds: 1280),
    const LectureModel(id: 3, surahId: 2, title: 'البقرة ١–٣٩ — هداية للمتقين', videoUrl: 'https://vz-12345678.b-cdn.net/2a/master.m3u8', subtitleUrl: 'https://cdn.tadabbur.app/subs/2a.vtt', durationSeconds: 1620),
    const LectureModel(id: 4, surahId: 12, title: 'قصة يوسف — الصبر والعفو', videoUrl: 'https://vz-12345678.b-cdn.net/12/master.m3u8', durationSeconds: 1470),
    const LectureModel(id: 5, surahId: 13, title: 'سورة الرعد — ألوان من التصوير', videoUrl: 'https://vz-12345678.b-cdn.net/13/master.m3u8', durationSeconds: 930),
    const LectureModel(id: 6, surahId: 112, title: 'الإخلاص — توحيد قريش', videoUrl: 'https://vz-12345678.b-cdn.net/112/master.m3u8', subtitleUrl: 'https://cdn.tadabbur.app/subs/112.vtt', durationSeconds: 820),
  ];
}
