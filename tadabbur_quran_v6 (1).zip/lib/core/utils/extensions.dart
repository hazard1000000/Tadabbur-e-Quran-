/// General-purpose BuildContext / String / num extensions.
extension StringX on String {
  bool get isNullOrEmpty => trim().isEmpty;
}

extension NumX on num {
  /// Converts a verse reference "2:255" style index into a display label.
  String get verseRef => toString();
}
