import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// Platform-native scrolling feel:
/// - iOS / macOS → Cupertino BouncingScrollPhysics (fluid rubber-band)
/// - Android / others → ClampingScrollPhysics (Material 3 stretch overscroll)
class AppScrollPhysics {
  AppScrollPhysics._();

  static ScrollPhysics platform(BuildContext context) {
    final platform = Theme.of(context).platform;
    final isApple = platform == TargetPlatform.iOS ||
        platform == TargetPlatform.macOS;
    return isApple ? const BouncingScrollPhysics() : const ClampingScrollPhysics();
  }
}
