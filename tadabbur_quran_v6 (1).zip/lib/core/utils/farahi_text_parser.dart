/// Smart Regex Parser for the Farahi master text block.
///
/// The admin pastes ONE block per ayah:
///
/// ```
/// [سوورەت: 94] [ئایەت: 5]
/// [عەرەبی:] فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا
/// [وەرگێڕان:] بەڵکو لەگەڵ سەختییەکەدا ئاسانییەک هەیە…
/// [نەزم:] پەیوەندی ئەم ئایەتە بە ئایەتی پێشوو…
/// [عەموود:] ناونوسی سوورەتەکە: فراوانی دڵ…
/// [تەدبّور:] بیرکردنەوە لە واقیعی مەککەی زمان…
/// [زمان:] (مَعَ) حرف جار…
/// ```
///
/// The parser splits the block into typed fields and hands them to the
/// Supabase upsert — no manual per-field entry. Tolerant by design:
/// Arabic-Indic digits (٩٤), ك/ک and ه/ە variants, stray diacritics/shadda
/// inside tags, and unknown tags (collected as warnings, never dropped).
class ParsedAyahBlock {
  const ParsedAyahBlock({
    required this.surahId,
    required this.ayahNumber,
    required this.arabicText,
    this.kurdishTranslation,
    this.nazm,
    this.amud,
    this.tadabbur,
    this.languageAnalysis,
    this.warnings = const [],
  });

  final int surahId;
  final int ayahNumber;
  final String arabicText;
  final String? kurdishTranslation;
  final String? nazm;
  final String? amud;
  final String? tadabbur;
  final String? languageAnalysis;
  final List<String> warnings;

  /// Row payload for `ayahs` upsert (column names match schema.sql).
  Map<String, dynamic> toSupabaseRow() => {
        'surah_id': surahId,
        'ayah_number': ayahNumber,
        'arabic_text': arabicText,
        'kurdish_translation': kurdishTranslation,
        'nazm': nazm,
        'amud': amud,
        'tadabbur': tadabbur,
        'language_analysis': languageAnalysis,
      };
}

class FarahiTextParser {
  FarahiTextParser._();

  /// Tolerates diacritics, shadda, tatweel and dagger-alif inside a tag.
  static const _fuzzy = r'[\u0640\u064B-\u0652\u0670\u06D6-\u06ED]*';

  /// Kurdish/Arabic char equivalence classes for tag keywords.
  static String _kw(String s) => s.split('').map((c) {
        switch (c) {
          case 'ک':
            return '(?:ک|ك)';
          case 'ە':
            return '(?:ە|ه)';
          case 'و':
            return '(?:و|ۆ)';
          case 'ی':
            return '(?:ی|ي)';
          default:
            return RegExp.escape(c);
        }
      }).join(_fuzzy);

  /// Keyword → field. Multiple accepted spellings map to one field
  /// (admin may write تەدبّور / تەدبور / تەدەبوور).
  static final Map<String, String> _fields = {
    'عەرەبی': 'arabic',
    'وەرگێڕان': 'translation',
    'نەزم': 'nazm',
    'عەموود': 'amud',
    'تەدبور': 'tadabbur',
    'تەدبّور': 'tadabbur',
    'تەدەبوور': 'tadabbur',
    'زمان': 'language',
  };

  static final RegExp _surahRe = RegExp(
    '\\[\\s*${_kw('سوورەت')}\\s*[:：]\\s*([0-9٠-٩]+)\\s*\\]',
  );
  static final RegExp _ayahRe = RegExp(
    '\\[\\s*${_kw('ئایەت')}\\s*[:：]\\s*([0-9٠-٩]+)\\s*\\]',
  );

  static int _toInt(String s) => int.parse(
        s.replaceAll('٠', '0').replaceAll('١', '1').replaceAll('٢', '2')
         .replaceAll('٣', '3').replaceAll('٤', '4').replaceAll('٥', '5')
         .replaceAll('٦', '6').replaceAll('٧', '7').replaceAll('٨', '8')
         .replaceAll('٩', '9'),
      );

  static String _clean(String s) =>
      s.trim().replaceAll(RegExp(r'\n{3,}'), '\n\n');

  /// Parses one master block. Throws [FormatException] when the mandatory
  /// header ([سوورەت] / [ئایەت]) or [عەرەبی:] section is missing.
  static ParsedAyahBlock parse(String block) {
    final warnings = <String>[];

    final surahM = _surahRe.firstMatch(block);
    final ayahM = _ayahRe.firstMatch(block);
    if (surahM == null || ayahM == null) {
      throw const FormatException(
        'Header missing: expected [سوورەت: X] [ئایەت: Y] at the top of the block.',
      );
    }
    final surahId = _toInt(surahM.group(1)!);
    final ayahNumber = _toInt(ayahM.group(1)!);
    if (surahId < 1 || surahId > 114) {
      throw FormatException('سوورەت must be 1–114, got $surahId.');
    }

    // Split sections on [tag] boundaries (positions from ORIGINAL text,
    // keywords matched fuzzily so diacritics/shadda never break slicing).
    final tagRe = RegExp(
      '\\[\\s*(${_fields.keys.map(_kw).join('|')})\\s*[:：]?\\s*\\]',
      multiLine: true,
    );
    final matches = tagRe.allMatches(block).toList();
    if (matches.isEmpty) {
      throw const FormatException('No [tag:] sections found in the block.');
    }

    final found = <String, String>{};
    for (var i = 0; i < matches.length; i++) {
      final m = matches[i];
      final end = (i + 1 < matches.length) ? matches[i + 1].start : block.length;
      final raw = m.group(1)!;
      final keyword = _fields.keys.firstWhere(
        (k) => _matchesFuzzy(k, raw),
        orElse: () => raw,
      );
      final field = _fields[keyword]!;
      final value = _clean(block.substring(m.end, end));
      if (value.isEmpty) {
        warnings.add('Section [$keyword] is empty.');
        continue;
      }
      if (found.containsKey(field)) {
        warnings.add('Section [$keyword] appears twice — later value kept.');
      }
      found[field] = value;
    }

    final arabic = found.remove('arabic');
    if (arabic == null) {
      throw const FormatException('Mandatory section [عەرەبی:] not found.');
    }

    return ParsedAyahBlock(
      surahId: surahId,
      ayahNumber: ayahNumber,
      arabicText: arabic,
      kurdishTranslation: found.remove('translation'),
      nazm: found.remove('nazm'),
      amud: found.remove('amud'),
      tadabbur: found.remove('tadabbur'),
      languageAnalysis: found.remove('language'),
      warnings: warnings,
    );
  }

  /// Compare a plain keyword against the fuzzy-captured group text by
  /// normalizing diacritics away on both sides.
  static bool _matchesFuzzy(String keyword, String captured) {
    String strip(String s) => s
        .replaceAll(RegExp(r'[\u0640\u064B-\u0652\u0670\u06D6-\u06ED]'), '')
        .replaceAll('ك', 'ک')
        .replaceAll('ه', 'ە')
        .replaceAll('ۆ', 'و')
        .replaceAll('ي', 'ی');
    return strip(keyword) == strip(captured);
  }
}
