import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_text_styles.dart';

abstract final class AppTheme {
  static ThemeData lightTheme(BuildContext context) => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.bg,
        fontFamily: 'Kurdish',
        textTheme: AppTextStyles.textTheme,
        colorScheme: ColorScheme.light(
          primary: AppColors.emerald,
          onPrimary: Colors.white,
          surface: AppColors.surface,
          secondary: AppColors.gold,
        ),
        cardTheme: CardThemeData(
          color: AppColors.surface,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: AppColors.gold.withValues(alpha: 0.35)),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: AppColors.bg,
          foregroundColor: AppColors.emerald,
        ),
        dividerTheme: DividerThemeData(
          color: AppColors.gold.withValues(alpha: 0.25),
          thickness: 1,
        ),
      );

  static ThemeData darkTheme(BuildContext context) => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bgDark,
        fontFamily: 'Kurdish',
        textTheme: AppTextStyles.textTheme,
        colorScheme: ColorScheme.dark(
          primary: AppColors.goldBright,
          onPrimary: Colors.black,
          surface: AppColors.surfaceDark,
          secondary: AppColors.goldBright,
        ),
        cardTheme: CardThemeData(
          color: AppColors.surfaceDark,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: Colors.white.withValues(alpha: 0.08)),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: AppColors.bgDark,
          foregroundColor: AppColors.goldBright,
        ),
        dividerTheme: DividerThemeData(
          color: Colors.white.withValues(alpha: 0.08),
          thickness: 1,
        ),
      );
}
