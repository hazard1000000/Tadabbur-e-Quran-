import 'package:flutter/material.dart';

/// Script-stable typography.
///
/// Android and iOS shape Arabic/Kurdish glyphs differently (different
/// system font fallbacks and default leading). Pinning `height` +
/// `leadingDistribution: proportional` makes line rhythm identical across
/// both platforms, and app.dart applies TextHeightBehavior with
/// applyHeightToFirstAscent/LastDescent so tall Uthmani ascenders and
/// descenders are never clipped by container bounds.
abstract final class AppTextStyles {
  /// Quranic text — generous line height for Uthmani stacked diacritics.
  static const TextStyle quranText = TextStyle(
    fontFamily: 'QuranUthmani',
    fontSize: 27,
    height: 2.2,
    leadingDistribution: TextLeadingDistribution.proportional,
  );

  /// Kurdish Tafsir — long paragraphs, comfortable reading rhythm.
  static const TextStyle tafsirText = TextStyle(
    fontFamily: 'Kurdish',
    fontSize: 15.5,
    height: 2.0,
    leadingDistribution: TextLeadingDistribution.proportional,
  );

  /// Compact pillar/tab labels.
  static const TextStyle pillarLabel = TextStyle(
    fontFamily: 'Kurdish',
    fontSize: 13.5,
    height: 1.4,
    leadingDistribution: TextLeadingDistribution.proportional,
  );

  /// Applied globally in app.dart — first ascent / last descent reserve
  /// room for tall Arabic glyphs so nothing is clipped on Dynamic-Island
  /// iPhones or custom-font Android devices.
  static const TextHeightBehavior heightBehavior = TextHeightBehavior(
    applyHeightToFirstAscent: true,
    applyHeightToLastDescent: true,
    leadingDistribution: TextLeadingDistribution.proportional,
  );

  static const TextStyle body = TextStyle(fontFamily: 'Kurdish', fontSize: 16, height: 1.6);
  static const TextStyle title = TextStyle(fontFamily: 'Kurdish', fontSize: 20, fontWeight: FontWeight.w700);
  static const TextStyle surahName = TextStyle(fontFamily: 'Kurdish', fontSize: 17, fontWeight: FontWeight.w600);

  static const TextTheme textTheme = TextTheme(
    bodyLarge: body,
    bodyMedium: body,
    titleLarge: title,
  );
}
