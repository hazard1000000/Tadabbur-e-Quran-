import 'package:flutter/material.dart';

/// Design tokens ported from tadabbur-v6 web app (:root CSS variables).
/// Warm cream parchment + deep emerald + royal gold.
abstract final class AppColors {
  // ---- v6 tokens ----
  static const Color bg = Color(0xFFF5F0E6);           // --bg
  static const Color surface = Color(0xFFFDFBF7);      // --surface
  static const Color surface2 = Color(0xFFF1E8D6);     // --surface-2
  static const Color ink = Color(0xFF092922);          // --ink
  static const Color ink2 = Color(0xFF244940);         // --ink-2
  static const Color muted = Color(0xFF67857B);        // --muted
  static const Color emerald = Color(0xFF0A3E35);      // --emerald
  static const Color emeraldLight = Color(0xFF156354); // --emerald-light
  static const Color gold = Color(0xFFB38222);         // --gold
  static const Color goldBright = Color(0xFFE5B84C);   // --gold-bright
  static const Color goldSoft = Color(0xFFFBF5E6);     // --gold-soft

  // Dark — deep emerald night
  static const Color bgDark = Color(0xFF041A16);
  static const Color surfaceDark = Color(0xFF092922);
  static const Color surfaceDark2 = Color(0xFF0F342C);

  // ---- Legacy aliases (keep existing widgets compiling) ----
  static const Color backgroundLight = bg;
  static const Color surfaceLight = surface;
  static const Color primary = emerald;
  static const Color onPrimary = Colors.white;
  static const Color secondary = gold;
  static const Color backgroundDark = bgDark;
  static const Color surfaceDarkHigh = surfaceDark2;
  static const Color goldDark = goldBright;
  static const Color quranTextLight = ink;
  static const Color quranTextDark = Color(0xFFE8E6E3);
}
