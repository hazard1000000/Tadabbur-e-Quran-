import 'package:flutter/material.dart';

abstract final class AppConstants {
  static const String appName = 'تدبر قرآن';
  static const String appVersion = '0.1.0';

  /// Locales: Kurdish (default), Arabic, English.
  static const Locale defaultLocale = Locale('ku');
  static const List<Locale> supportedLocales = [
    Locale('ku'),
    Locale('ar'),
    Locale('en'),
  ];
}
