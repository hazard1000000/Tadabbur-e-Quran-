/// Revelation type of a Surah.
enum RevelationType { meccan, medinan }

extension RevelationTypeX on RevelationType {
  String get arabicLabel => this == RevelationType.meccan ? 'مكية' : 'مدنية';
  String get kurdishLabel => this == RevelationType.meccan ? 'مەککەیی' : 'مدینەیی';

  static RevelationType fromJson(String value) =>
      value == 'medinan' ? RevelationType.medinan : RevelationType.meccan;
}
