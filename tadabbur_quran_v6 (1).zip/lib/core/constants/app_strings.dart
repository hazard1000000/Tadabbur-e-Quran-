/// App-wide localized strings.
///
/// Day 1 placeholder — will be replaced by generated ARB/`.arb` files +
/// `gen_l10n` once the localization workflow is finalized.
abstract final class AppStrings {
  static const String homeTitle = 'تدبر قرآن';
  static const String quranTitle = 'القرآن الكريم';
  static const String lecturesTitle = 'دەرسەکان';
  static const String settingsTitle = 'ڕێکخستنەکان';
}
