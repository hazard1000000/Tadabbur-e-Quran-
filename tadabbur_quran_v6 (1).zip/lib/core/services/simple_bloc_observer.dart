import 'package:flutter_bloc/flutter_bloc.dart';

/// Logs BLoC transitions in debug builds.
class SimpleBlocObserver extends BlocObserver {
  const SimpleBlocObserver();

  @override
  void onChange(BlocBase bloc, Change change) {
    super.onChange(bloc, change);
    // In production, swap for a proper logger (e.g. talker_bloc_logger).
    // ignore: avoid_print
    print('${bloc.runtimeType} $change');
  }

  @override
  void onError(BlocBase bloc, Object error, StackTrace stackTrace) {
    super.onError(bloc, error, stackTrace);
    // ignore: avoid_print
    print('${bloc.runtimeType} error: $error');
  }
}
