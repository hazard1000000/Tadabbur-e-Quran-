/// Placeholder HTTP client service.
///
/// Day 1 stub — the real implementation (Dio or http) will be added once the
/// backend/CMS decision (Firebase / Strapi / Supabase) is finalized.
class ApiClient {
  // static const String baseUrl = '';
  // final Dio _dio = Dio(...);
}
