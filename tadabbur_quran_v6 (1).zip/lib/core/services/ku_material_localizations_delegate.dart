import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

/// Kurdish (`ku`) is not bundled in flutter_localizations.
/// This delegate reuses the **Arabic** Material/Cupertino strings (correct for
/// RTL) while reporting the language as Kurdish.
class KuMaterialLocalizationsDelegate extends LocalizationsDelegate<MaterialLocalizations> {
  const KuMaterialLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ku';

  @override
  Future<MaterialLocalizations> load(Locale locale) async {
    const arabicDelegate = GlobalMaterialLocalizations.delegate;
    final material = await arabicDelegate.load(const Locale('ar'));
    return _KuMaterialLocalizations(material);
  }

  @override
  bool shouldReload(KuMaterialLocalizationsDelegate old) => false;
}

class _KuMaterialLocalizations implements MaterialLocalizations {
  _KuMaterialLocalizations(this._delegate);

  final MaterialLocalizations _delegate;

  @override
  String get languageCode => 'ku';

  // --- Everything else forwards to the Arabic delegate ---
  @override
  dynamic noSuchMethod(Invocation invocation) => Function.apply(
        Function.apply(_delegate.noSuchMethod, [invocation]) as Function,
        const [],
      );
}

/// Cupertino delegate for Kurdish (same trick).
class KuCupertinoLocalizationsDelegate extends LocalizationsDelegate<CupertinoLocalizations> {
  const KuCupertinoLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ku';

  @override
  Future<CupertinoLocalizations> load(Locale locale) async {
    const arabicDelegate = GlobalCupertinoLocalizations.delegate;
    final cupertino = await arabicDelegate.load(const Locale('ar'));
    return _KuCupertinoLocalizations(cupertino);
  }

  @override
  bool shouldReload(KuCupertinoLocalizationsDelegate old) => false;
}

class _KuCupertinoLocalizations extends CupertinoLocalizations {
  _KuCupertinoLocalizations(this._delegate);

  final CupertinoLocalizations _delegate;

  @override
  String get languageCode => 'ku';

  @override
  dynamic noSuchMethod(Invocation invocation) =>
      Function.apply(Function.apply(_delegate.noSuchMethod, [invocation]) as Function, const []);
}
