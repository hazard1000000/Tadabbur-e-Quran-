import 'package:supabase_flutter/supabase_flutter.dart';

/// App-side Supabase access (read-only, anon key).
class SupabaseService {
  SupabaseService._();

  static final _client = Supabase.instance.client;

  static Future<List<Map<String, dynamic>>> fetchSurahs() =>
      _client.from('surahs').select().order('id');

  /// Surahs with their group + twin data in one round trip.
  static Future<List<Map<String, dynamic>>> fetchSurahsWithStructure() => _client
      .from('surahs')
      .select('*, group:quran_groups(*), twin:paired_surah_id(*)')
      .order('id');

  static Future<List<Map<String, dynamic>>> fetchGroups() =>
      _client.from('quran_groups').select().order('group_number');

  static Future<List<Map<String, dynamic>>> fetchAyahs(int surahId) =>
      _client.from('ayahs').select().eq('surah_id', surahId).order('ayah_number');

  static Future<List<Map<String, dynamic>>> fetchLectures(int surahId) =>
      _client.from('lectures').select().eq('surah_id', surahId).order('sort_order');

  /// Full-text search across Arabic text + Kurdish Tafsir (GIN index in schema).
  static Future<List<Map<String, dynamic>>> search(String query) =>
      _client.from('ayahs').select().textSearch('search_vector', query);
}
