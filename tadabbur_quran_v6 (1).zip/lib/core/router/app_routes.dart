abstract final class AppRoutes {
  static const String quran = '/quran';
  static const String lectures = '/lectures';
  static const String settings = '/settings';
  static const String hub = '/hub';

  static String quranSurah(int surahId) => '/quran/$surahId';
  static String lectureDetail(int lectureId) => '/lectures/$lectureId';
}
