import 'package:go_router/go_router.dart';

import '../../features/home/presentation/views/home_shell.dart';
import '../../features/hub/presentation/views/knowledge_hub_page.dart';
import '../../features/lectures/presentation/views/lectures_page.dart';
import '../../features/quran/presentation/views/quran_page.dart';
import '../../features/quran/presentation/views/surah_details_page.dart';
import '../../features/settings/presentation/views/settings_page.dart';
import 'app_routes.dart';

abstract final class AppRouter {
  static final router = GoRouter(
    initialLocation: AppRoutes.quran,
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => HomeShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(path: AppRoutes.quran, builder: (context, state) => const QuranPage()),
              GoRoute(
                path: '${AppRoutes.quran}/:surahId',
                builder: (context, state) => SurahDetailsPage(
                  surahId: int.parse(state.pathParameters['surahId']!),
                ),
              ),
              // Farahi School Knowledge Hub (pushed, bottom nav preserved).
              GoRoute(path: AppRoutes.hub, builder: (context, state) => const KnowledgeHubPage()),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(path: AppRoutes.lectures, builder: (context, state) => const LecturesPage()),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(path: AppRoutes.settings, builder: (context, state) => const SettingsPage()),
            ],
          ),
        ],
      ),
    ],
  );
}
