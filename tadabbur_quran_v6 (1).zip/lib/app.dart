import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/constants/app_constants.dart';
import 'core/router/app_router.dart';
import 'core/services/ku_material_localizations_delegate.dart';
import 'core/theme/app_text_styles.dart';
import 'core/theme/app_theme.dart';
import 'features/settings/presentation/bloc/settings_cubit.dart';

class TadabburApp extends StatelessWidget {
  const TadabburApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => SettingsCubit(),
      child: Builder(
        builder: (context) {
          final settings = context.watch<SettingsCubit>().state;
          return MaterialApp.router(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            // ---- RTL: default text direction is Right-to-Left ----
            builder: (context, child) => Directionality(
              textDirection: TextDirection.rtl,
              // Global anti-clip: reserve ascent/descent for Uthmani glyphs.
              child: DefaultTextHeightBehavior(
                textHeightBehavior: AppTextStyles.heightBehavior,
                child: child ?? const SizedBox.shrink(),
              ),
            ),
            // ---- Localization ----
            locale: settings.locale,
            supportedLocales: AppConstants.supportedLocales,
            localizationsDelegates: const [
              KuMaterialLocalizations.delegate, // Kurdish (falls back to Arabic strings)
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            localeResolutionCallback: (deviceLocale, supported) {
              if (deviceLocale == null) return AppConstants.defaultLocale;
              for (final l in supported) {
                if (l.languageCode == deviceLocale.languageCode) return l;
              }
              return AppConstants.defaultLocale; // Kurdish
            },
            // ---- Theme ----
            theme: AppTheme.lightTheme(context),
            darkTheme: AppTheme.darkTheme(context),
            themeMode: settings.themeMode,
            routerConfig: AppRouter.router,
          );
        },
      ),
    );
  }
}
