import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/app_constants.dart';
import '../bloc/settings_cubit.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.watch<SettingsCubit>();
    return Scaffold(
      appBar: AppBar(title: const Text('ڕێکخستنەکان')),
      body: ListView(
        physics: const AlwaysScrollableScrollPhysics(), // inherits platform parent
        children: [
          const ListTile(title: Text('زمان / Language')),
          RadioGroup<Locale>(
            groupValue: cubit.state.locale,
            onChanged: (l) => cubit.setLocale(l ?? AppConstants.defaultLocale),
            child: const Column(
              children: [
                RadioListTile(value: Locale('ku'), title: Text('کوردی'), controlAffinity: ListTileControlAffinity.trailing),
                RadioListTile(value: Locale('ar'), title: Text('العربية'), controlAffinity: ListTileControlAffinity.trailing),
                RadioListTile(value: Locale('en'), title: Text('English'), controlAffinity: ListTileControlAffinity.trailing),
              ],
            ),
          ),
          const Divider(),
          // Adaptive switch: renders Cupertino switch on iOS, Material on Android.
          ListTile(
            title: const Text('دۆخی تاریک / Dark mode'),
            trailing: Switch.adaptive(
              value: cubit.state.themeMode == ThemeMode.dark,
              onChanged: (v) => cubit.setThemeMode(v ? ThemeMode.dark : ThemeMode.light),
            ),
          ),
        ],
      ),
    );
  }
}
