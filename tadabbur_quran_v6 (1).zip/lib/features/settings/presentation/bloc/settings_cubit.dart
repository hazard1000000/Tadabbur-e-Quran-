import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/constants/app_constants.dart';

class SettingsState extends Equatable {
  const SettingsState({this.locale = AppConstants.defaultLocale, this.themeMode = ThemeMode.system});

  final Locale locale;
  final ThemeMode themeMode;

  SettingsState copyWith({Locale? locale, ThemeMode? themeMode}) =>
      SettingsState(locale: locale ?? this.locale, themeMode: themeMode ?? this.themeMode);

  @override
  List<Object?> get props => [locale, themeMode];
}

class SettingsCubit extends Cubit<SettingsState> {
  SettingsCubit() : super(const SettingsState());

  void setLocale(Locale locale) => emit(state.copyWith(locale: locale));
  void setThemeMode(ThemeMode mode) => emit(state.copyWith(themeMode: mode));
}
