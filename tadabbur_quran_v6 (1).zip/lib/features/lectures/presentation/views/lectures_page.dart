import 'package:flutter/material.dart';

import '../../../../core/constants/app_strings.dart';
import '../../../../core/dummy_data.dart';
import '../../../../core/utils/scroll_physics.dart';
import '../widgets/lecture_card.dart';

class LecturesPage extends StatelessWidget {
  const LecturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final lectures = DummyData.lectures;

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.lecturesTitle)),
      body: GridView.builder(
        physics: AppScrollPhysics.platform(context), // bounce iOS / clamp Android
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 420, // one column on phones, two on tablets
          childAspectRatio: 1.35,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
        ),
        itemCount: lectures.length,
        itemBuilder: (context, index) => LectureCard(lecture: lectures[index]),
      ),
    );
  }
}
