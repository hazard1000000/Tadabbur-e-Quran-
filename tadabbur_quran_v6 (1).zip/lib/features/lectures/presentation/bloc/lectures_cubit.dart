import 'package:flutter_bloc/flutter_bloc.dart';

import '../../data/models/lecture_model.dart';

class LecturesState {
  const LecturesState({this.lectures = const [], this.loading = false, this.error});

  final List<LectureModel> lectures;
  final bool loading;
  final String? error;
}

class LecturesCubit extends Cubit<LecturesState> {
  LecturesCubit() : super(const LecturesState());
  // TODO(Day 2+): wire to repository, streaming/subtitle handling.
}
