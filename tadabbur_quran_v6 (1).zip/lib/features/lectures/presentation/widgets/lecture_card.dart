import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../data/models/lecture_model.dart';

/// Lecture card: 16:9 thumbnail placeholder with play overlay, title,
/// duration badge and subtitle (CC) indicator.
class LectureCard extends StatelessWidget {
  const LectureCard({super.key, required this.lecture, this.onTap});

  final LectureModel lecture;
  final VoidCallback? onTap;

  String get _durationLabel {
    final s = lecture.durationSeconds;
    if (s == null) return '';
    return '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldDark : AppColors.gold;
    final thumbBg = isDark ? AppColors.surfaceDarkHigh : const Color(0xFFECEAE4);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail placeholder with play overlay
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                color: thumbBg,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.ondemand_video_outlined, size: 40, color: gold.withValues(alpha: 0.6)),
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.black.withValues(alpha: 0.55),
                        border: Border.all(color: gold, width: 1.4),
                      ),
                      child: Icon(Icons.play_arrow, color: gold, size: 26),
                    ),
                    if (_durationLabel.isNotEmpty)
                      Positioned(
                        bottom: 8,
                        left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            _durationLabel,
                            style: const TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'Kurdish'),
                          ),
                        ),
                      ),
                    if (lecture.subtitleUrl != null)
                      Positioned(
                        bottom: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: gold.withValues(alpha: 0.9),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'CC · کوردی',
                            style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                lecture.title,
                style: const TextStyle(fontFamily: 'Kurdish', fontSize: 14.5, fontWeight: FontWeight.w600),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
