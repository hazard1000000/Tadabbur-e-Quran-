import 'package:equatable/equatable.dart';

/// A video lecture (Nouman Ali Khan), streamed externally with Kurdish subtitles.
class LectureModel extends Equatable {
  const LectureModel({
    required this.id,
    required this.surahId,
    required this.title,
    required this.videoUrl,
    this.subtitleUrl,
    this.durationSeconds,
    this.thumbnailUrl,
  });

  final int id;
  final int surahId;
  final String title;

  /// YouTube watch URL or CDN URL, depending on final streaming decision.
  final String videoUrl;

  /// VTT/SRT subtitle file (Kurdish).
  final String? subtitleUrl;

  final int? durationSeconds;
  final String? thumbnailUrl;

  /// YouTube video ID when [videoUrl] is a YouTube link (extracted lazily).
  String? get youtubeId {
    final uri = Uri.tryParse(videoUrl);
    if (uri == null || uri.host.contains('youtu') == false) return null;
    if (uri.queryParameters.containsKey('v')) return uri.queryParameters['v'];
    final segs = uri.pathSegments;
    return segs.isNotEmpty ? segs.last : null;
  }

  factory LectureModel.fromJson(Map<String, dynamic> json) => LectureModel(
        id: json['id'] as int,
        surahId: json['surah_id'] as int,
        title: json['title'] as String,
        videoUrl: json['video_url'] as String,
        subtitleUrl: json['subtitle_url'] as String?,
        durationSeconds: json['duration_seconds'] as int?,
        thumbnailUrl: json['thumbnail_url'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'surah_id': surahId,
        'title': title,
        'video_url': videoUrl,
        'subtitle_url': subtitleUrl,
        'duration_seconds': durationSeconds,
        'thumbnail_url': thumbnailUrl,
      };

  @override
  List<Object?> get props => [id, surahId, title, videoUrl, subtitleUrl, durationSeconds, thumbnailUrl];
}
