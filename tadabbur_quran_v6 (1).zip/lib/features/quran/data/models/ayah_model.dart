import 'package:equatable/equatable.dart';

/// One ayah with all Farahi pillars, mirroring `supabase/schema.sql`.
class AyahModel extends Equatable {
  const AyahModel({
    required this.surahId,
    required this.ayahNumber,
    required this.arabicText,
    this.kurdishTranslation,
    this.nazm,
    this.amud,
    this.tadabbur,
    this.languageAnalysis,
  });

  final int surahId;
  final int ayahNumber;
  final String arabicText;

  /// [وەرگێڕان] — Kurdish translation.
  final String? kurdishTranslation;

  /// [نەزم] — structural coherence (how the ayah connects to its context).
  final String? nazm;

  /// [عەموود] — the surah's central theme / axis as it appears in this ayah.
  final String? amud;

  /// [تەدبّور] — deep reflections, historical context (Islahi's Tadabbur).
  final String? tadabbur;

  /// [زمان] — linguistic, morphological and rhetorical analysis.
  final String? languageAnalysis;

  factory AyahModel.fromJson(Map<String, dynamic> json) => AyahModel(
        surahId: json['surah_id'] as int,
        ayahNumber: json['ayah_number'] as int,
        arabicText: json['arabic_text'] as String,
        kurdishTranslation: json['kurdish_translation'] as String?,
        nazm: json['nazm'] as String?,
        amud: json['amud'] as String?,
        tadabbur: json['tadabbur'] as String?,
        languageAnalysis: json['language_analysis'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'surah_id': surahId,
        'ayah_number': ayahNumber,
        'arabic_text': arabicText,
        'kurdish_translation': kurdishTranslation,
        'nazm': nazm,
        'amud': amud,
        'tadabbur': tadabbur,
        'language_analysis': languageAnalysis,
      };

  @override
  List<Object?> get props => [
        surahId, ayahNumber, arabicText, kurdishTranslation,
        nazm, amud, tadabbur, languageAnalysis,
      ];
}
