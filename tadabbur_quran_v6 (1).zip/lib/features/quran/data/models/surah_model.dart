import 'package:equatable/equatable.dart';

import '../../../../core/constants/enums.dart';

/// A Surah with its Farahi macro-structure position:
/// seven-group membership and structural twin (الزوج القرآني).
class SurahModel extends Equatable {
  const SurahModel({
    required this.id,
    required this.arabicName,
    required this.kurdishName,
    required this.revelationType,
    required this.totalAyahs,
    this.groupNumber,
    this.pairedSurahId,
    this.pairingContextKu,
  });

  final int id;
  final String arabicName;
  final String kurdishName;
  final RevelationType revelationType;
  final int totalAyahs;

  /// 1–7 — the surah's Quranic Group (Islahi's seven مجموعات).
  final int? groupNumber;

  /// Structural twin surah id (e.g. 94 ↔ 93), null until curated.
  final int? pairedSurahId;

  /// Kurdish academic summary of the twin link (e.g. Al-Duha ↔ Al-Sharh).
  final String? pairingContextKu;

  factory SurahModel.fromJson(Map<String, dynamic> json) => SurahModel(
        id: json['id'] as int,
        arabicName: json['arabic_name'] as String,
        kurdishName: json['kurdish_name'] as String,
        revelationType: RevelationTypeX.fromJson(json['revelation_type'] as String),
        totalAyahs: json['total_ayahs'] as int,
        groupNumber: json['group_number'] as int?,
        pairedSurahId: json['paired_surah_id'] as int?,
        pairingContextKu: json['pairing_context_ku'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'arabic_name': arabicName,
        'kurdish_name': kurdishName,
        'revelation_type': revelationType.name,
        'total_ayahs': totalAyahs,
        'group_number': groupNumber,
        'paired_surah_id': pairedSurahId,
        'pairing_context_ku': pairingContextKu,
      };

  @override
  List<Object?> get props => [
        id, arabicName, kurdishName, revelationType, totalAyahs,
        groupNumber, pairedSurahId, pairingContextKu,
      ];
}
