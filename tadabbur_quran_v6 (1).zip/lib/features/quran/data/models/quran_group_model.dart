import 'package:equatable/equatable.dart';

/// One of the Seven Quranic Groups (Islahi's macro-structure).
class QuranGroupModel extends Equatable {
  const QuranGroupModel({
    required this.groupNumber,
    required this.nameAr,
    required this.nameKu,
    required this.themeKu,
    required this.firstSurah,
    required this.lastSurah,
  });

  final int groupNumber;
  final String nameAr;
  final String nameKu;
  final String themeKu;
  final int firstSurah;
  final int lastSurah;

  factory QuranGroupModel.fromJson(Map<String, dynamic> json) => QuranGroupModel(
        groupNumber: json['group_number'] as int,
        nameAr: json['name_ar'] as String,
        nameKu: json['name_ku'] as String,
        themeKu: json['theme_ku'] as String,
        firstSurah: json['first_surah'] as int,
        lastSurah: json['last_surah'] as int,
      );

  Map<String, dynamic> toJson() => {
        'group_number': groupNumber,
        'name_ar': nameAr,
        'name_ku': nameKu,
        'theme_ku': themeKu,
        'first_surah': firstSurah,
        'last_surah': lastSurah,
      };

  @override
  List<Object?> get props => [groupNumber, nameAr, nameKu, themeKu, firstSurah, lastSurah];
}
