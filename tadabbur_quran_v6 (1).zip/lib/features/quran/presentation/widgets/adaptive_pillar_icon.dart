import 'dart:math' as math;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// Pillar index ↔ adaptive iconography, each with its own organic
/// micro-animation that fires when the tab becomes active.
///
/// 0 نەزم        — hub nodes expand outward while the network rotates gently
/// 1 ستوون       — the pillar stretches upward and settles
/// 2 تێڕامان     — the book rocks like a page being turned, then rests
/// 3 زمانەوانی   — the globe pulses once, softly
///
/// All motion is pure `TweenAnimationBuilder` (built-in, no packages),
/// 60fps on both Android and iOS.
class AdaptivePillarIcon extends StatelessWidget {
  const AdaptivePillarIcon({
    super.key,
    required this.pillar,
    required this.selected,
    this.size = 19,
  });

  final int pillar;
  final bool selected;
  final double size;

  static const _material = [
    Icons.hub_outlined,          // network / structure
    Icons.architecture,          // pillar / axis
    Icons.auto_stories_outlined, // deep reading
    Icons.translate,             // linguistics
  ];

  static const _cupertino = [
    CupertinoIcons.link,              // connections
    CupertinoIcons.building_2_fill,   // column
    CupertinoIcons.book_fill,         // reading
    CupertinoIcons.globe,             // language
  ];

  @override
  Widget build(BuildContext context) {
    final platform = Theme.of(context).platform;
    final isApple = platform == TargetPlatform.iOS ||
        platform == TargetPlatform.macOS;
    final icon = Icon(
      isApple ? _cupertino[pillar] : _material[pillar],
      size: size,
    );

    // One-shot emphasis animation: when `selected` flips true, v tweens
    // 0 → 1; deselecting tweens back to rest. Each pillar composes a
    // different transform from v for a distinct, organic motion.
    return TweenAnimationBuilder<double>(
      key: ValueKey('pillar-$pillar-selected-$selected'),
      tween: Tween(begin: 0, end: selected ? 1 : 0),
      duration: const Duration(milliseconds: 480),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) {
        return switch (pillar) {
          0 => Transform.rotate(
                // نەزم: gentle rotation + expanding nodes
                angle: v * 0.45,
                child: Transform.scale(
                  scale: 1 + 0.20 * math.sin(v * math.pi * 0.75),
                  child: child,
                ),
              ),
          1 => Transform.scale(
                // ستوون: smooth vertical stretch, slight widen
                scaleX: 1 + 0.07 * v,
                scaleY: 1 + 0.24 * math.sin(v * math.pi * 0.6),
                child: child,
              ),
          2 => Transform.rotate(
                // تێڕامان: book rocks -8° → +8° → settles at 0
                angle: math.sin(v * math.pi) * 0.28,
                child: child,
              ),
          _ => Transform.scale(
                // زمانەوانی: soft double pulse
                scale: 1 + 0.16 * math.sin(v * math.pi) + 0.06 * math.sin(v * math.pi * 2),
                child: child,
              ),
        };
      },
      child: icon,
    );
  }
}
