import 'package:flutter/material.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/surah_model.dart';

/// Card for one Surah: circular number avatar, Arabic name, Kurdish name, ayah count.
class SurahListTile extends StatelessWidget {
  const SurahListTile({super.key, required this.surah, this.onTap});

  final SurahModel surah;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldDark : AppColors.gold;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              // Circular surah number avatar
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: gold, width: 1.4),
                ),
                child: Center(
                  child: Text(
                    '${surah.id}',
                    style: TextStyle(
                      fontFamily: 'Kurdish',
                      fontWeight: FontWeight.w700,
                      color: gold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(surah.arabicName, style: const TextStyle(fontFamily: 'Kurdish', fontSize: 17, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(
                      '${surah.kurdishName} · ${surah.totalAyahs} آية',
                      style: TextStyle(
                        fontFamily: 'Kurdish',
                        fontSize: 13,
                        color: isDark ? Colors.white60 : Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: gold.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  surah.revelationType.kurdishLabel,
                  style: TextStyle(fontFamily: 'Kurdish', fontSize: 12, color: gold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
