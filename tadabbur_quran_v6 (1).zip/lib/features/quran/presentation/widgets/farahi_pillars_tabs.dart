import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/scroll_physics.dart';
import '../../data/models/ayah_model.dart';
import 'adaptive_pillar_icon.dart';

/// The four Farahi pillars — short scholarly labels, adaptive animated
/// iconography, animated segmented control.
///
/// - نەزم · ستوون · تێڕامان · زمانەوانی (punchy, fits small screens)
/// - Icons perform an organic micro-animation on selection
/// - Sliding gold underline indicator (RTL-aware)
/// - AnimatedSwitcher crossfade + AnimatedSize for stable layout
/// - Long pillar texts scroll with platform-native physics
class FarahiPillarsTabs extends StatefulWidget {
  const FarahiPillarsTabs({super.key, required this.ayah});

  final AyahModel ayah;

  @override
  State<FarahiPillarsTabs> createState() => _FarahiPillarsTabsState();
}

class _FarahiPillarsTabsState extends State<FarahiPillarsTabs> {
  int _index = 0;

  /// Short, punchy Kurdish pillar titles (Farahi school terminology).
  static const _labels = ['نەزم', 'ستوون', 'تێڕامان', 'زمانەوانی'];

  String? _contentFor(int i) {
    final a = widget.ayah;
    return switch (i) {
      0 => a.nazm,               // نەزم
      1 => a.amud,               // ستوون
      2 => a.tadabbur,           // تێڕامان
      _ => a.languageAnalysis,   // زمانەوانی
    };
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldDark : AppColors.gold;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // ---- Segmented control with sliding indicator ----
        SizedBox(
          height: 58,
          child: Stack(
            children: [
              AnimatedAlign(
                alignment: Alignment(_rtlFraction(_index, _labels.length), 0),
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutCubic,
                child: FractionallySizedBox(
                  widthFactor: 1 / _labels.length,
                  heightFactor: 1,
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: gold, width: 2.4),
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                children: List.generate(_labels.length, (i) {
                  final selected = i == _index;
                  return Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => setState(() => _index = i),
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 220),
                        style: AppTextStyles.pillarLabel.copyWith(
                          fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                          color: selected
                              ? gold
                              : (isDark ? Colors.white38 : Colors.black38),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AdaptivePillarIcon(
                              pillar: i,
                              selected: selected,
                              size: 20,
                            ),
                            const SizedBox(height: 4),
                            Text(_labels[i], textAlign: TextAlign.center),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // ---- Animated pillar content ----
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 280),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) => FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.06),
                end: Offset.zero,
              ).animate(animation),
              child: child,
            ),
          ),
          child: KeyedSubtree(
            key: ValueKey(_index),
            child: AnimatedSize(
              duration: const Duration(milliseconds: 240),
              curve: Curves.easeOut,
              child: _buildContent(_contentFor(_index), gold, isDark),
            ),
          ),
        ),
      ],
    );
  }

  /// RTL-aware indicator fraction: index 0 sits on the RIGHT side.
  double _rtlFraction(int i, int n) => (1 - (2 * i + 1) / n);

  Widget _buildContent(String? content, Color gold, bool isDark) {
    if (content == null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.auto_awesome_outlined, size: 16, color: gold.withValues(alpha: 0.6)),
            const SizedBox(width: 8),
            Text(
              'ئەم بەشە لە ئامادەکردن دایە…',
              style: TextStyle(
                fontFamily: 'Kurdish',
                fontStyle: FontStyle.italic,
                fontSize: 13,
                color: isDark ? Colors.white38 : Colors.black38,
              ),
            ),
          ],
        ),
      );
    }
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 260),
      child: SingleChildScrollView(
        physics: AppScrollPhysics.platform(context),
        child: Text(
          content,
          style: AppTextStyles.tafsirText.copyWith(
            color: isDark ? AppColors.quranTextDark : AppColors.quranTextLight,
          ),
          textAlign: TextAlign.right,
        ),
      ),
    );
  }
}
