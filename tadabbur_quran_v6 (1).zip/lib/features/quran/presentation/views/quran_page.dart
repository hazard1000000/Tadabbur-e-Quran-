import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_strings.dart';
import '../../../../core/dummy_data.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/utils/scroll_physics.dart';
import '../widgets/surah_list_tile.dart';

/// Home — matches the v6 web app: Gateway Card (ناساندنی قوتابخانەی فەراهی),
/// Stats Row, Search, filter pills, and the surah list.
class QuranPage extends StatefulWidget {
  const QuranPage({super.key});

  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage> {
  String _query = '';
  String _filter = 'all'; // all | meccan | medinan

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldBright : AppColors.gold;
    final ink = isDark ? AppColors.quranTextDark : AppColors.ink;

    var surahs = DummyData.surahs;
    if (_filter == 'meccan') {
      surahs = surahs.where((s) => s.revelationType.name == 'meccan').toList();
    }
    if (_filter == 'medinan') {
      surahs = surahs.where((s) => s.revelationType.name == 'medinan').toList();
    }
    if (_query.isNotEmpty) {
      surahs = surahs
          .where((s) => s.arabicName.contains(_query) || s.kurdishName.contains(_query))
          .toList();
    }

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.quranTitle)),
      body: ListView(
        physics: AppScrollPhysics.platform(context),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          // ---- Gateway Card ----
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: isDark ? AppColors.surfaceDark : AppColors.surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: gold.withValues(alpha: 0.5), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: AppColors.emerald.withValues(alpha: 0.10),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: isDark ? AppColors.surfaceDark2 : AppColors.goldSoft,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: gold.withValues(alpha: 0.4)),
                      ),
                      child: Text(
                        'ئەندازیاریی نەزم',
                        style: TextStyle(fontFamily: 'Kurdish', fontSize: 11.5, color: gold, fontWeight: FontWeight.w700),
                      ),
                    ),
                    const Spacer(),
                    Text('پێوەر: ١:١١', style: const TextStyle(fontFamily: 'Kurdish', fontSize: 11, color: AppColors.muted)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'ناساندنی قوتابخانەی فەراهی',
                  style: TextStyle(fontFamily: 'Kurdish', fontSize: 19, fontWeight: FontWeight.w800, height: 1.5, color: gold),
                ),
                const SizedBox(height: 8),
                Text(
                  'تێڕامان لە تەلاری قورئان لە ڕوانگەی ئیمام فەراهی و مەولانا ئیسلاحییەوە؛ کە تێیدا پەیڤ و ئایەتەکان وەک خشتی تاشراوی کەوانەیەکی بەردین لێکدراون و لە دەوری یەک ستوونی نەگۆڕ (العَمُود)دا دەسووڕێنەوە.',
                  style: TextStyle(fontFamily: 'Kurdish', fontSize: 13, height: 2.0, color: ink),
                  textAlign: TextAlign.right,
                ),
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: () => context.push(AppRoutes.hub),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.emerald,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.architecture, color: AppColors.goldBright, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'گەشتی تێڕامان و تەلارسازی',
                          style: TextStyle(fontFamily: 'Kurdish', fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.goldBright),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          // ---- Stats Row ----
          Row(
            children: [
              _stat('١١٤', 'سوورەت', 'تەلاری وەحی', gold, isDark),
              _stat('٧', 'کۆمەڵە', 'ڕەهەندی گەورە', gold, isDark),
              _stat('٥٧', 'جووت', 'هاوسەنگیی دووانە', gold, isDark),
              _stat('٣٠', 'پارە', 'جوزئەکان', gold, isDark),
            ],
          ),
          const SizedBox(height: 14),
          // ---- Search ----
          TextField(
            onChanged: (v) => setState(() => _query = v.trim()),
            style: const TextStyle(fontFamily: 'Kurdish', fontSize: 14),
            decoration: InputDecoration(
              hintText: 'بگەڕێ بۆ سوورەت…',
              hintStyle: const TextStyle(fontFamily: 'Kurdish', fontSize: 13),
              prefixIcon: const Icon(Icons.search, size: 20),
              filled: true,
              fillColor: isDark ? AppColors.surfaceDark : AppColors.surface,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: gold.withValues(alpha: 0.35)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: gold.withValues(alpha: 0.35)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: gold, width: 1.4),
              ),
            ),
          ),
          const SizedBox(height: 10),
          // ---- Filter pills ----
          Row(
            children: [
              _pill('هەموو', 'all', gold, isDark),
              const SizedBox(width: 8),
              _pill('مەککی', 'meccan', gold, isDark),
              const SizedBox(width: 8),
              _pill('مەدەنی', 'medinan', gold, isDark),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'پێڕستی ١١٤ سوورەتەکە',
            style: TextStyle(fontFamily: 'Kurdish', fontSize: 16, fontWeight: FontWeight.w800, color: ink),
          ),
          const SizedBox(height: 8),
          ...surahs.map(
            (s) => SurahListTile(surah: s, onTap: () => context.push(AppRoutes.quranSurah(s.id))),
          ),
        ],
      ),
    );
  }

  Widget _stat(String num, String label, String sub, Color gold, bool isDark) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isDark ? AppColors.surfaceDark : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: gold.withValues(alpha: 0.35)),
        ),
        child: Column(
          children: [
            Text(num, style: TextStyle(fontFamily: 'QuranUthmani', fontSize: 22, fontWeight: FontWeight.w700, color: gold)),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Kurdish',
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: isDark ? AppColors.quranTextDark : AppColors.ink,
              ),
            ),
            Text(sub, style: const TextStyle(fontFamily: 'Kurdish', fontSize: 10, color: AppColors.muted)),
          ],
        ),
      ),
    );
  }

  Widget _pill(String label, String key, Color gold, bool isDark) {
    final active = _filter == key;
    return GestureDetector(
      onTap: () => setState(() => _filter = key),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.emerald : (isDark ? AppColors.surfaceDark : AppColors.surface),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? AppColors.emerald : gold.withValues(alpha: 0.4)),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'Kurdish',
            fontSize: 12.5,
            fontWeight: FontWeight.w600,
            color: active ? AppColors.goldBright : (isDark ? AppColors.quranTextDark : AppColors.ink),
          ),
        ),
      ),
    );
  }
}
