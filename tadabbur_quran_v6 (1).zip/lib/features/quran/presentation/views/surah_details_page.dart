import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/dummy_data.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/scroll_physics.dart';
import '../../data/models/ayah_model.dart';
import '../../data/models/surah_model.dart';
import '../widgets/farahi_pillars_tabs.dart';

/// Surah details: 30% video, slim "surah twin" banner, 70% ayah list with
/// the animated four-pillar analysis. The twin banner navigates to the
/// paired surah; its trailing icon toggles the pairing-context overlay.
class SurahDetailsPage extends StatefulWidget {
  const SurahDetailsPage({super.key, required this.surahId});

  final int surahId;

  @override
  State<SurahDetailsPage> createState() => _SurahDetailsPageState();
}

class _SurahDetailsPageState extends State<SurahDetailsPage> {
  bool _showPairing = false;

  @override
  Widget build(BuildContext context) {
    final surah = DummyData.surahs.firstWhere(
      (s) => s.id == widget.surahId,
      orElse: () => const SurahModel(id: 94, arabicName: 'الشرح', kurdishName: 'الانشراح', revelationType: RevelationType.meccan, totalAyahs: 8),
    );
    final twin = surah.pairedSurahId != null
        ? DummyData.surahById(surah.pairedSurahId!)
        : null;
    final ayahs = DummyData.ayahsFor(surah.id);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldDark : AppColors.gold;

    return Scaffold(
      appBar: AppBar(title: Text('سورة ${surah.arabicName}')),
      body: Stack(
        children: [
          Column(
            children: [
              // ---- Top 30%: video player placeholder (Bunny — Day 5) ----
              Expanded(
                flex: 3,
                child: Container(
                  width: double.infinity,
                  color: isDark ? AppColors.surfaceDarkHigh : const Color(0xFFECEAE4),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(Icons.ondemand_video_outlined, size: 44, color: gold.withValues(alpha: 0.55)),
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black.withValues(alpha: 0.55),
                          border: Border.all(color: gold, width: 1.6),
                        ),
                        child: Icon(Icons.play_arrow, color: gold, size: 32),
                      ),
                      Positioned(
                        bottom: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.6),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            'Bunny Stream player',
                            style: TextStyle(color: Colors.white70, fontSize: 11),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // ---- Surah Twin banner ----
              if (twin != null)
                _SurahTwinBanner(
                  surah: surah,
                  twin: twin,
                  gold: gold,
                  isDark: isDark,
                  onNavigate: () => context.push(AppRoutes.quranSurah(twin.id)),
                  onToggleContext: () => setState(() => _showPairing = !_showPairing),
                ),
              // ---- Ayah + pillar list ----
              Expanded(
                flex: 7,
                child: ListView.builder(
                  physics: AppScrollPhysics.platform(context),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: ayahs.length,
                  itemBuilder: (context, index) => _AyahTile(ayah: ayahs[index], gold: gold),
                ),
              ),
            ],
          ),
          // ---- Pairing context overlay ----
          if (_showPairing)
            _PairingOverlay(
              surah: surah,
              twin: twin,
              gold: gold,
              isDark: isDark,
              onClose: () => setState(() => _showPairing = false),
              onGoToTwin: () {
                setState(() => _showPairing = false);
                context.push(AppRoutes.quranSurah(twin!.id));
              },
            ),
        ],
      ),
    );
  }
}

/// "هاوتای سوورەتەکە" — premium banner: tap navigates to the twin,
/// trailing button toggles the academic pairing overlay.
class _SurahTwinBanner extends StatelessWidget {
  const _SurahTwinBanner({
    required this.surah,
    required this.twin,
    required this.gold,
    required this.isDark,
    required this.onNavigate,
    required this.onToggleContext,
  });

  final SurahModel surah;
  final SurahModel twin;
  final Color gold;
  final bool isDark;
  final VoidCallback onNavigate;
  final VoidCallback onToggleContext;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gold, width: 1.2),
        color: gold.withValues(alpha: 0.07),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onNavigate,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Icon(Icons.join_inner_outlined, color: gold, size: 22),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'هاوتای سوورەتەکە',
                        style: TextStyle(
                          fontFamily: 'Kurdish',
                          fontSize: 12.5,
                          color: isDark ? Colors.white60 : Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'سورة ${twin.arabicName} · ${twin.kurdishName}',
                        style: TextStyle(
                          fontFamily: 'Kurdish',
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                          color: gold,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'پەیوەندی هاوتا / pairing context',
                  icon: Icon(Icons.info_outline_rounded, color: gold),
                  onPressed: onToggleContext,
                ),
                Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: gold),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Full-context overlay: dimmed backdrop + gold-bordered panel showing
/// `pairing_context_ku`, with a direct "open the twin" action.
class _PairingOverlay extends StatelessWidget {
  const _PairingOverlay({
    required this.surah,
    required this.twin,
    required this.gold,
    required this.isDark,
    required this.onClose,
    required this.onGoToTwin,
  });

  final SurahModel surah;
  final SurahModel? twin;
  final Color gold;
  final bool isDark;
  final VoidCallback onClose;
  final VoidCallback onGoToTwin;

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: 1,
      duration: const Duration(milliseconds: 220),
      child: GestureDetector(
        onTap: onClose, // tap outside dismisses
        child: Container(
          color: Colors.black.withValues(alpha: 0.55),
          alignment: Alignment.bottomCenter,
          child: GestureDetector(
            onTap: () {}, // keep panel taps inside
            child: AnimatedSlide(
              offset: Offset.zero,
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
                decoration: BoxDecoration(
                  color: isDark ? AppColors.surfaceDark : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: gold.withValues(alpha: 0.5)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.join_inner_outlined, color: gold, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            twin == null
                                ? 'پەیوەندی هاوتا'
                                : '${surah.kurdishName} ↔ ${twin!.kurdishName}',
                            style: TextStyle(
                              fontFamily: 'Kurdish',
                              fontSize: 15.5,
                              fontWeight: FontWeight.w700,
                              color: gold,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded, size: 20),
                          color: isDark ? Colors.white54 : Colors.black45,
                          onPressed: onClose,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flexible(
                      child: SingleChildScrollView(
                        physics: AppScrollPhysics.platform(context),
                        child: Text(
                          surah.pairingContextKu ??
                              'پەیوەندی هاوتاكان لە ئامادەکردن دایە…',
                          style: TextStyle(
                            fontFamily: 'Kurdish',
                            fontSize: 14,
                            height: 2.0,
                            leadingDistribution: TextLeadingDistribution.proportional,
                            color: isDark
                                ? AppColors.quranTextDark
                                : AppColors.quranTextLight,
                          ),
                          textAlign: TextAlign.right,
                        ),
                      ),
                    ),
                    if (twin != null) ...[
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: gold,
                          foregroundColor: Colors.black,
                        ),
                        onPressed: onGoToTwin,
                        icon: const Icon(Icons.open_in_new_rounded, size: 18),
                        label: const Text(
                          'بڕۆ بۆ هاوتا',
                          style: TextStyle(fontFamily: 'Kurdish', fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AyahTile extends StatelessWidget {
  const _AyahTile({required this.ayah, required this.gold});

  final AyahModel ayah;
  final Color gold;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '${ayah.arabicText} ﴿${ayah.ayahNumber}﴾',
            style: AppTextStyles.quranText.copyWith(color: gold),
            textAlign: TextAlign.right,
          ),
          const SizedBox(height: 8),
          Divider(color: gold.withValues(alpha: 0.25)),
          const SizedBox(height: 8),
          if (ayah.kurdishTranslation != null)
            Text(
              ayah.kurdishTranslation!,
              style: AppTextStyles.tafsirText.copyWith(
                color: isDark ? AppColors.quranTextDark : AppColors.quranTextLight,
              ),
              textAlign: TextAlign.right,
            )
          else
            Text(
              'وەرگێڕان لە ئامادەکردن دایە…',
              style: TextStyle(
                fontFamily: 'Kurdish',
                fontStyle: FontStyle.italic,
                color: Colors.grey.withValues(alpha: 0.7),
                fontSize: 13.5,
              ),
            ),
          const SizedBox(height: 14),
          FarahiPillarsTabs(ayah: ayah),
          const SizedBox(height: 10),
          Divider(color: gold.withValues(alpha: 0.18), thickness: 4),
        ],
      ),
    );
  }
}
