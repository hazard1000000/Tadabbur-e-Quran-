import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/dummy_data.dart';
import '../../data/models/surah_model.dart';

class QuranState {
  const QuranState({this.surahs = const [], this.loading = false, this.error});

  final List<SurahModel> surahs;
  final bool loading;
  final String? error;

  QuranState copyWith({List<SurahModel>? surahs, bool? loading, String? error}) =>
      QuranState(surahs: surahs ?? this.surahs, loading: loading ?? this.loading, error: error);
}

class QuranCubit extends Cubit<QuranState> {
  QuranCubit() : super(const QuranState()) {
    loadSurahs();
  }

  Future<void> loadSurahs() async {
    emit(state.copyWith(loading: true));
    try {
      // TODO(Day 3+): repository stream from CMS/Firebase.
      emit(state.copyWith(loading: false, surahs: DummyData.surahs));
    } catch (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    }
  }
}
