import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/dummy_data.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/scroll_physics.dart';

/// ناساندنی قوتابخانەی فەراهی — the Farahi Portal, matching the v6 web app.
/// Tabs: زانایان · کەوانە و عەموود · حەوت کۆمەڵە · ٥٧ جووتەکە · زمانی کۆن
class KnowledgeHubPage extends StatefulWidget {
  const KnowledgeHubPage({super.key});

  @override
  State<KnowledgeHubPage> createState() => _KnowledgeHubPageState();
}

class _KnowledgeHubPageState extends State<KnowledgeHubPage> {
  int _tab = 0;
  static const _tabs = ['زانایان', 'کەوانە و عەموود', 'حەوت کۆمەڵە', '٥٧ جووتەکە', 'زمانی کۆن'];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final gold = isDark ? AppColors.goldDark : AppColors.gold;
    final ink = isDark ? AppColors.quranTextDark : AppColors.ink;

    return Scaffold(
      appBar: AppBar(title: const Text('ناساندنی قوتابخانەی فەراهی')),
      body: Column(
        children: [
          // ---- Portal header ----
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Column(
              children: [
                Text(
                  'شۆڕشی ڕەوانبێژی: لە تەفسیری پچڕپچڕەوە بۆ تەلاری پەیوەست',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Kurdish',
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    height: 1.7,
                    color: ink,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '«كِتَابٌ أُحْكِمَتْ آيَاتُهُ ثُمَّ فُصِّلَتْ»',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontFamily: 'QuranUthmani', fontSize: 20, color: gold, height: 1.8),
                ),
                const SizedBox(height: 4),
                Text('ئیمام فەراهی', style: TextStyle(fontFamily: 'Kurdish', fontSize: 12.5, color: AppColors.muted)),
              ],
            ),
          ),
          // ---- Tab bar (horizontal scroll, as web app) ----
          SizedBox(
            height: 44,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _tabs.length,
              itemBuilder: (context, i) {
                final active = i == _tab;
                return GestureDetector(
                  onTap: () => setState(() => _tab = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    margin: const EdgeInsets.only(left: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: active ? AppColors.emerald : (isDark ? AppColors.surfaceDark : AppColors.surface),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: active ? AppColors.emerald : gold.withValues(alpha: 0.45)),
                    ),
                    child: Text(
                      _tabs[i],
                      style: TextStyle(
                        fontFamily: 'Kurdish',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: active ? AppColors.goldBright : ink,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              child: switch (_tab) {
                0 => _scholars(isDark, gold, ink),
                1 => _arch(isDark, gold, ink),
                2 => _groups(isDark, gold, ink),
                3 => _pairs(isDark, gold, ink),
                _ => _lexicon(isDark, gold, ink),
              },
            ),
          ),
        ],
      ),
    );
  }

  // ---- ١ زانایان ----
  Widget _scholars(bool isDark, Color gold, Color ink) {
    const scholars = [
      (
        'ئیمام فەراهی',
        'حەمزە عەبدولڕەحیم فەراهی (١٨٦٣–١٩٣٠) — زانایەکی مەدرەسەی عەرەبی عومەرییەکان. نەزمی قورئانی دەرخست و بە «نەزم و عەموود» ناسرا.\n\n«كِتَابٌ أُحْكِمَتْ آيَاتُهُ» — قورئان تەلارێکی پەیوەستە، نەك کۆمەڵە بابەتێکی بێبەری.',
      ),
      (
        'مەولانا ئیسلاحی',
        'ئەمین ئەحسەن ئیسلاحی (١٩٠٤–١٩٩٧) — قوتابی ئیمام فەراهی. تەدبوری قورئانی لە چەند جildدا نووسی و ئەمڕۆ «مێراتی فەراهی»یە.',
      ),
    ];
    return ListView(
      key: const ValueKey('scholars'),
      physics: AppScrollPhysics.platform(context),
      padding: const EdgeInsets.all(16),
      children: [
        ...scholars.map(
          (s) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? AppColors.surfaceDark : AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: gold.withValues(alpha: 0.45)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.auto_awesome, color: gold, size: 18),
                    const SizedBox(width: 8),
                    Text(s.$1, style: TextStyle(fontFamily: 'Kurdish', fontSize: 16, fontWeight: FontWeight.w800, color: gold)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(s.$2, style: AppTextStyles.tafsirText.copyWith(fontSize: 13.5, color: ink), textAlign: TextAlign.right),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ---- ٢ کەوانە و عەموود ----
  Widget _arch(bool isDark, Color gold, Color ink) {
    return ListView(
      key: const ValueKey('arch'),
      physics: AppScrollPhysics.platform(context),
      padding: const EdgeInsets.all(16),
      children: [
        _box(
          isDark, gold, ink,
          'حیکمەتی تاقی کەوانە و بەردی قفڵ (العَمُود)',
          'هەر سوورەتێک تاقی کەوانەیەکی بەردینە: دەستپێک (A) و کۆتایی (A′) وەک دوو ستونی تاقەکە، و لە ناوەڕاستدا «بەردی قفڵ» — العَمُود — ستونێکی نەگۆڕ کە هەموو ئایەتەکان دەوری دەگرنەوە.',
        ),
        _box(
          isDark, gold, ink,
          'نەخشەی تاقی کەوانەی نەزم',
          'هێڵکاریی زیندوو: دەستپێک (A) → بەردی قفڵ (العَمُود) ⭐ → کۆتایی (A′). ئەم هێڵکارییە هەموو سوورەتێکی دەکاتە یەک بینای ئەندازەیی.',
          center: 'دەستپێک (A) ··········· ⭐ العَمُود ··········· کۆتایی (A′)',
        ),
      ],
    );
  }

  // ---- ٣ حەوت کۆمەڵە ----
  Widget _groups(bool isDark, Color gold, Color ink) {
    final groups = DummyData.groups;
    return ListView(
      key: const ValueKey('groups'),
      physics: AppScrollPhysics.platform(context),
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'حەوت گەردەلوولی گەورەی وەحی',
          style: TextStyle(fontFamily: 'Kurdish', fontSize: 15, fontWeight: FontWeight.w800, color: gold),
        ),
        const SizedBox(height: 4),
        Text(
          'قورئان ڕووبارێکی یەکڕەوت نییە، بەڵکو دابەش دەبێت بەسەر ٧ کۆمەڵەی ئەندازیاریدا — هەر کۆمەڵەیەک لە سوورەتێکی مەککەییەوە دەست پێدەکات و بە مەدەنییەک کۆتایی دێت.',
          style: AppTextStyles.tafsirText.copyWith(fontSize: 13, color: ink),
          textAlign: TextAlign.right,
        ),
        const SizedBox(height: 14),
        ...groups.map(
          (g) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: isDark ? AppColors.surfaceDark : AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: gold.withValues(alpha: 0.4)),
            ),
            child: Row(
              children: [
                Text('${g.groupNumber}', style: TextStyle(fontFamily: 'QuranUthmani', fontSize: 26, color: gold)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(g.nameKu, style: TextStyle(fontFamily: 'Kurdish', fontSize: 14.5, fontWeight: FontWeight.w800, color: ink)),
                      Text(g.themeKu, style: TextStyle(fontFamily: 'Kurdish', fontSize: 12, height: 1.8, color: AppColors.muted)),
                    ],
                  ),
                ),
                Text('${g.firstSurah}–${g.lastSurah}', style: TextStyle(fontFamily: 'Kurdish', fontSize: 11, color: gold)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ---- ٤ ٥٧ جووتەکە ----
  Widget _pairs(bool isDark, Color gold, Color ink) {
    return ListView(
      key: const ValueKey('pairs'),
      physics: AppScrollPhysics.platform(context),
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'یاسای هاوسەنگیی دووانەیی (الزوجية)',
          style: TextStyle(fontFamily: 'Kurdish', fontSize: 15, fontWeight: FontWeight.w800, color: gold),
        ),
        const SizedBox(height: 12),
        ...DummyData.pairs.map(
          (p) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Expanded(child: _pairCard(p.$1.arabicName, p.$1.id, gold, isDark, ink)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Column(
                    children: [
                      Container(width: 1, height: 14, color: gold.withValues(alpha: 0.5)),
                      Icon(Icons.compare_arrows_rounded, size: 16, color: gold),
                      Container(width: 1, height: 14, color: gold.withValues(alpha: 0.5)),
                    ],
                  ),
                ),
                Expanded(child: _pairCard(p.$2.arabicName, p.$2.id, gold, isDark, ink)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _pairCard(String name, int id, Color gold, bool isDark, Color ink) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceDark : AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gold.withValues(alpha: 0.45)),
      ),
      child: Column(
        children: [
          Text('$id', style: TextStyle(fontFamily: 'QuranUthmani', fontSize: 17, color: gold)),
          Text(name, style: TextStyle(fontFamily: 'Kurdish', fontSize: 13.5, fontWeight: FontWeight.w800, color: ink)),
        ],
      ),
    );
  }

  // ---- ٥ زمانی کۆن ----
  Widget _lexicon(bool isDark, Color gold, Color ink) {
    return ListView(
      key: const ValueKey('lex'),
      physics: AppScrollPhysics.platform(context),
      padding: const EdgeInsets.all(16),
      children: [
        _box(
          isDark, gold, ink,
          'فەرهەنگناسیی ڕەوانبێژانەی زمانی پێش ئیسلام',
          'بۆ دۆزینەوەی واتای ڕەسەنی وشە قورئانییەکان، فەراهی شیعری عەرەبی جاهیلی و ڕەگە سامییەکان (عەبری، ئارامی، حەبشی) بەکاردەهێنێت — نەك تەنیا فەرهەنگەکانی سەردەمی خۆی.',
        ),
        _box(
          isDark, gold, ink,
          'نموونە: صَلَاة',
          'وشەی «صَلَاة» لە ڕەگە سامییەوە دێت بمانای «پەیوەستبوون بە خواوە» — ئەم واتا ڕەسەنە وردبینی هەموو ئایەتەکانی دەگۆڕێت.',
        ),
      ],
    );
  }

  Widget _box(bool isDark, Color gold, Color ink, String title, String body, {String? center}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceDark : AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: gold.withValues(alpha: 0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontFamily: 'Kurdish', fontSize: 15, fontWeight: FontWeight.w800, color: gold, height: 1.6),
          ),
          const SizedBox(height: 8),
          Text(body, style: AppTextStyles.tafsirText.copyWith(fontSize: 13.5, color: ink), textAlign: TextAlign.right),
          if (center != null) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: isDark ? AppColors.surfaceDark2 : AppColors.goldSoft,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                center,
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'Kurdish', fontSize: 12.5, fontWeight: FontWeight.w700, color: gold),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
