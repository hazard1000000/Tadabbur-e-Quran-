import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../../../core/theme/app_colors.dart';

/// Pillar motion asset: plays a Lottie vector animation when the artist
/// drops `assets/motion/pillar_<n>.json` into the project; until then it
/// renders a gracefully-animated fallback icon so the UI never breaks.
///
/// Also responds to tap state: [pressed] compresses the asset slightly.
class PillarMotionAsset extends StatelessWidget {
  const PillarMotionAsset({
    super.key,
    required this.pillar,
    this.size = 30,
    this.pressed = false,
  });

  final int pillar;
  final double size;
  final bool pressed;

  static const _fallbackIcons = [
    Icons.view_column_outlined,
    Icons.join_inner_outlined,
    Icons.architecture,
    Icons.hub_outlined,
    Icons.menu_book_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).brightness == Brightness.dark
        ? AppColors.goldDark
        : AppColors.gold;

    return AnimatedScale(
      scale: pressed ? 0.88 : 1,
      duration: const Duration(milliseconds: 140),
      curve: Curves.easeOut,
      child: SizedBox(
        width: size,
        height: size,
        child: Lottie.asset(
          'assets/motion/pillar_$pillar.json',
          repeat: true,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) => TweenAnimationBuilder<double>(
            key: ValueKey('fallback-$pillar'),
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1600),
            builder: (context, v, child) => Transform.scale(
              scale: 1 + 0.07 * (v < 0.5 ? v * 2 : (1 - v) * 2),
              child: child,
            ),
            child: Icon(_fallbackIcons[pillar], size: size * 0.8, color: gold),
          ),
        ),
      ),
    );
  }
}
